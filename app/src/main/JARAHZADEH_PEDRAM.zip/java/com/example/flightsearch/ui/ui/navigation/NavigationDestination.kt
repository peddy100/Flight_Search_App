/*
    Pedram Jarahzadeh / jarahzap@oregonstate.edu
    CS 492 / Oregon State University
*/
package com.example.flightsearch.ui.ui.navigation

interface NavigationDestination {
    val route: String
    val titleRes: Int
}